/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication16newtonraphson;

/**
 *
 * @author Murtaza Kazmi
 */
public class JavaApplication16NewtonRaphson {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Answer is " + nr(0, 0.1));
    }
    
    static double nr(double xn, double err){
        double xnn = 0;
        int iter = 0;
        do{
            iter++;
            xnn = xn;
            xn = xnn - (f(xnn)/fgradient(xnn));
            System.out.println(iter + "th = " + xn);
        }while(Math.abs(f(xn)-f(xnn)) > err);
        
        return xn;
    }
    static double f(double x){
        return 3*x - Math.cos(x*57.3) -1;
    }
    static double fgradient(double x){
        return 3 + Math.sin(x*57.3);
    }
    
}
