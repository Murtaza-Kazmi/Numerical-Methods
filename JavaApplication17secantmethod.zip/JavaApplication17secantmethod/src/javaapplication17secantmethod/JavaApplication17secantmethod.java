/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication17secantmethod;

/**
 *
 * @author Murtaza Kazmi
 */
public class JavaApplication17secantmethod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Answer is " + secant(1,2, 0.01));
    }
    
    static double secant(double xim1, double xi, double err){
        int iter = 1;
        double xip1 = xi - ((f(xi)*(xim1 - xi))/(f(xim1)-f(xi)));
        System.out.println(iter + "th = " + xip1);
        do{
            iter++;
            
            xim1 = xi;
            xi = xip1;
            
            xip1 = xi - ((f(xi)*(xim1 - xi))/(f(xim1)-f(xi)));
            System.out.println(iter + "th = " + xip1);
        }while(Math.abs((f(xip1-f(xi)))) > err);
        return xip1;
        
    }
    static double f(double x){
        return  Math.pow(x, 2) - 10;
    }
    //Math.cos(x*57.3) + 2 * Math.sin(x*57.3) + x*x
    // 1 1 1 1 1 1 1 1
     // 1 2 4 8 16 32 64
}
