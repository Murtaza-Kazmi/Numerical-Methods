/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication15;

/**
 *
 * @author Murtaza Kazmi
 */
public class JavaApplication15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Answer is " + ModFalsePos(2.5,1.0,0.001));
        //note: err = relative error
        
    }
    
    static double ModFalsePos(double xl,double xu, double err){
        int iter = 0;
        double xrold = 0;
        double xr = 0;
        double fl = f(xl);
        double fu = f(xu);
        do{
            iter++;
            xrold = xr;
            xr = xu - fu * (xl-xu)/(fl-fu);
            double fr = f(xr);
            if(f(xr) < 0){
               xu = xr; 
            }
            else{
                xl = xr;
            }
            System.out.println(iter + "th = " + xr);
            
        } while(Math.abs((xr-xrold)/xr)*100 > err);
        return xr;
    }

    private static double f(double x) {
        return Math.pow(x, 2) - x -2;
    }

    
}
